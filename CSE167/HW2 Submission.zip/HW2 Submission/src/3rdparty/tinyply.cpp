#define TINYPLY_IMPLEMENTATION
#include "tinyply.h"