# Custom Scene
My custome scene json and ply for HW2.5 is in:
scenes>hw2>hw_2_5>custom.json
scenes>hw2>hw_2_5>apple.ply

The rendering is in
outputs>hw_2_5_apple.png

# Credit
Credit to the artists of the 3d apple:

- Direct Link to Account: https://sketchfab.com/kuwalol93

- Direct Link to Apple Model: https://sketchfab.com/3d-models/apple-low-poly-triangulated-bc2c7bdad9fb49d989ef6cc88d47ef07
